<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: page10A.php");
    exit;
}

include 'dbcon.php';
$query = "SELECT * FROM peminjam";
$result = $pdo->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjam</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Irish+Grover&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="StyleKu.css?v=<?php echo time(); ?>">
</head>

<body>
    <header>
        <div>
            <h1 style="font-family: Irish Grover;">KOMIKU READER</h1>
            <button type="button" id="burger-menu" style="padding: 0; background-color: transparent;">
                <img src="./HiMenu.svg" alt="" style="width: 26px;">
            </button>
            <button type="button" id="close-menu" style="display: none; padding: 0; background-color: transparent;"">
                <img src=" ./HiOutlineX.svg" alt="" style="width: 26px;">
            </button>
        </div>
        <nav id="mainNav">
            <ul>
                <li><a href="Komiku.php">Beranda</a></li>
                <li><a href="page09A.php">Daftar Komik</a></li>
                <li><a href="page09B.php" class="active-menu">Daftar Peminjam</a></li>
                <li><a href="page09D.php">Tambah Peminjam</a></li>
                <li><a href="page09C.php">Tambah Komik</a></li>
                <li><a href="page10B.php">Log Out</a></li>
            </ul>
        </nav>
    </header>

    <main style="overflow-x: scroll;">
        <table class="peminjam">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result) {
                    foreach ($result as $row) { ?>
                        <tr>
                            <td><?php echo $row["id"]; ?></td>
                            <td><?php echo $row["nama"]; ?></td>
                            <td><?php echo $row["email"]; ?></td>
                            <td>
                                <a href='page09E.php?id=<?php echo $row["id"]; ?>&nama=<?php echo $row["nama"]; ?>&email=<?php echo $row["email"]; ?>'><img src='edit-icon.png' style='width:30px;height:30px;'></a>
                                <a href='page09F.php?id=<?php echo $row["id"]; ?>' onclick='return confirmDelete()'><img src='delete-icon.png' style='width:30px;height:30px;'></a>
                            </td>
                        </tr>
                <?php   }
                } else {
                    echo "<tr><td colspan='4'>Tidak ada data peminjam</td></tr>";
                }
                ?>
                <tr>
                    <td colspan="4">
                        <button onclick="window.location.href='page09D.php'">Tambah Peminjam</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </main>
    <footer>
        <p style="color: white;">Copyright &copy; 2024 Politeknik Statistika STIS</p>
        <p style="color: white;">Created by Shafnanda Aulia Kamal (222212878@stis.ac.id)</p>
    </footer>
    <script>
        function confirmDelete() {
            return confirm("Apakah anda yakin menghapus elemen ini?");
        }
    </script>
    <script src="./navbarMenu.js"></script>
</body>

</html>